function Footer() {
  return (
    <footer className="footer">
      <div className="footer-container">

        <h2>ShopZone</h2>

        <p>
          Your one-stop destination for quality products at the best prices.
        </p>

        <p className="copyright">
          © 2026 ShopZone. All rights reserved.
        </p>

      </div>
    </footer>
  );
}

export default Footer;