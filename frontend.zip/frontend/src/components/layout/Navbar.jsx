
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { useCart } from "../../context/CartContext";

function Navbar() {
  const { user, isLoggedIn, logout } = useAuth();
  const { cartCount } = useCart();
  const navigate = useNavigate();

  const requireLogin = (path) => {
    if (!isLoggedIn) {
      alert("Please login first to continue.");
      navigate("/login", { state: { from: path } });
      return;
    }

    navigate(path);
  };

  const handleLogout = () => {
    logout();
    navigate("/");
    alert("You have logged out successfully.");
  };

  return (
    <>
      <header className="main-header">
        <div className="header-container">
          <Link to="/" className="brand">
            <div className="brand-name">ShopZone</div>
            <div className="brand-subtitle">
              Explore <span>Plus ✦</span>
            </div>
          </Link>

          <div className="search-box">
            <span className="search-icon">🔍</span>
            <input
              type="text"
              placeholder="Search for products, brands and more"
              onKeyDown={(event) => {
                if (event.key === "Enter") {
                  navigate(
                    `/products?search=${encodeURIComponent(
                      event.currentTarget.value
                    )}`
                  );
                }
              }}
            />
          </div>

          <div className="header-actions">
            {!isLoggedIn ? (
              <>
                <Link to="/login" className="login-button">
                  Login
                </Link>
                <Link to="/register" className="seller-link">
                  Register
                </Link>
              </>
            ) : (
              <>
                <button
                  className="login-button"
                  onClick={() =>
                    requireLogin(
                      user?.role === "admin"
                        ? "/admin"
                        : "/profile"
                    )
                  }
                >
                  {user?.name || "My Account"}
                </button>

                {user?.role === "admin" && (
                  <Link to="/admin" className="seller-link">
                    Admin Panel
                  </Link>
                )}

                <button
                  className="more-button"
                  onClick={handleLogout}
                >
                  Logout
                </button>
              </>
            )}

            <button
              className="cart-link"
              onClick={() => requireLogin("/cart")}
            >
              🛒 <span>Cart ({cartCount})</span>
            </button>
          </div>
        </div>
      </header>

      <div className="category-bar">
        <div className="category-container">
          <Link to="/products">📱 Mobiles</Link>
          <Link to="/products">💻 Electronics</Link>
          <Link to="/products">👕 Fashion</Link>
          <Link to="/products">🏠 Home</Link>
          <Link to="/products">📺 Appliances</Link>
          <Link to="/products">🛒 Grocery</Link>
          <Link to="/products">💄 Beauty</Link>
          <Link to="/products">🧸 Toys</Link>
          <Link to="/products">✈️ Travel</Link>
        </div>
      </div>
    </>
  );
}

export default Navbar;
