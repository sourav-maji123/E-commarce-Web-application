function Checkout() {
  return (
    <div style={{ padding: "60px", textAlign: "center" }}>
      <h1>Checkout</h1>
      <p>Checkout page coming soon.</p>
    </div>
  );
}

export default Checkout;