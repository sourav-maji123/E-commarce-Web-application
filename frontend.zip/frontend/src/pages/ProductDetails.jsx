import { useParams } from "react-router-dom";

function ProductDetails() {
  const { id } = useParams();

  return (
    <div style={{ padding: "60px", textAlign: "center" }}>
      <h1>Product Details</h1>
      <p>Product ID: {id}</p>
    </div>
  );
}

export default ProductDetails;