function Cart() {
  return (
    <div style={{ padding: "60px", textAlign: "center" }}>
      <h1>Your Cart</h1>
      <p>Your cart is currently empty.</p>
    </div>
  );
}

export default Cart;