
import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";

function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const [loginType, setLoginType] = useState("user");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");
    setLoading(true);

    try {
      const loggedInUser = await login(
        email.trim(),
        password,
        loginType
      );

      const requestedPath = location.state?.from;

      // Do not redirect an Admin to a regular user's page,
      // or a regular User to an Admin page.
      if (loggedInUser.role === "admin") {
        navigate("/admin", { replace: true });
      } else if (
        typeof requestedPath === "string" &&
        !requestedPath.startsWith("/admin")
      ) {
        navigate(requestedPath, { replace: true });
      } else {
        navigate("/", { replace: true });
      }
    } catch (err) {
      setError(err.message || "Login failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        <Link to="/" className="auth-brand">
          ShopZone
        </Link>

        <h1>Welcome Back!</h1>
        <p className="auth-subtitle">
          Choose your account type to continue.
        </p>

        {location.state?.message && (
          <div className="auth-success" role="status">
            {location.state.message}
          </div>
        )}

        <div className="login-type-switch">
          <button
            type="button"
            className={loginType === "user" ? "active" : ""}
            onClick={() => {
              setLoginType("user");
              setError("");
            }}
          >
            👤 User Login
          </button>

          <button
            type="button"
            className={loginType === "admin" ? "active" : ""}
            onClick={() => {
              setLoginType("admin");
              setError("");
            }}
          >
            🛡️ Admin Login
          </button>
        </div>

        <p className="login-type-description">
          {loginType === "admin"
            ? "Sign in with your authorized Admin account."
            : "Sign in to shop, manage your cart and view your orders."}
        </p>

        {error && (
          <div className="auth-error" role="alert">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <label htmlFor="login-email">Email Address</label>
          <input
            id="login-email"
            type="email"
            placeholder="Enter your email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            autoComplete="email"
            required
          />

          <label htmlFor="login-password">Password</label>
          <input
            id="login-password"
            type="password"
            placeholder="Enter your password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            autoComplete="current-password"
            required
          />

          <button
            type="submit"
            className="auth-submit"
            disabled={loading}
          >
            {loading
              ? "Please wait..."
              : loginType === "admin"
                ? "Login as Admin"
                : "Login as User"}
          </button>
        </form>

        {loginType === "user" && (
          <p className="auth-switch">
            Don't have an account?{" "}
            <Link to="/register">Create Account</Link>
          </p>
        )}

        {loginType === "admin" && (
          <p className="auth-switch">
            Admin accounts are created by the site owner.
          </p>
        )}

        <Link to="/" className="auth-home-link">
          ← Continue browsing as a guest
        </Link>
      </div>
    </div>
  );
}

export default Login;
