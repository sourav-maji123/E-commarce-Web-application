import { Link } from "react-router-dom";

const products = [
  {
    id: 1,
    name: "Wireless Headphones",
    category: "Electronics",
    price: 1499,
    oldPrice: 2999,
    rating: 4.4,
    emoji: "🎧",
  },
  {
    id: 2,
    name: "Smart Watch",
    category: "Electronics",
    price: 2499,
    oldPrice: 4999,
    rating: 4.5,
    emoji: "⌚",
  },
  {
    id: 3,
    name: "Running Shoes",
    category: "Fashion",
    price: 1999,
    oldPrice: 3999,
    rating: 4.3,
    emoji: "👟",
  },
  {
    id: 4,
    name: "Laptop Backpack",
    category: "Fashion",
    price: 899,
    oldPrice: 1799,
    rating: 4.2,
    emoji: "🎒",
  },
  {
    id: 5,
    name: "Smartphone",
    category: "Mobiles",
    price: 15999,
    oldPrice: 19999,
    rating: 4.6,
    emoji: "📱",
  },
  {
    id: 6,
    name: "Gaming Laptop",
    category: "Electronics",
    price: 54999,
    oldPrice: 69999,
    rating: 4.7,
    emoji: "💻",
  },
  {
    id: 7,
    name: "Bluetooth Speaker",
    category: "Electronics",
    price: 1299,
    oldPrice: 2499,
    rating: 4.4,
    emoji: "🔊",
  },
  {
    id: 8,
    name: "Casual T-Shirt",
    category: "Fashion",
    price: 599,
    oldPrice: 999,
    rating: 4.1,
    emoji: "👕",
  },
];

function Products() {
  return (
    <div className="products-page">

      <div className="products-header">
        <div>
          <h1>All Products</h1>
          <p>Explore our latest collection</p>
        </div>

        <select className="sort-select">
          <option>Sort by: Popular</option>
          <option>Price: Low to High</option>
          <option>Price: High to Low</option>
          <option>Newest First</option>
        </select>
      </div>

      <div className="products-layout">

        {/* Sidebar */}
        <aside className="filter-sidebar">

          <h3>Filters</h3>

          <div className="filter-group">
            <h4>Categories</h4>

            <label>
              <input type="checkbox" />
              Mobiles
            </label>

            <label>
              <input type="checkbox" />
              Electronics
            </label>

            <label>
              <input type="checkbox" />
              Fashion
            </label>

            <label>
              <input type="checkbox" />
              Home
            </label>

          </div>

          <div className="filter-group">
            <h4>Price</h4>

            <label>
              <input type="checkbox" />
              Under ₹1,000
            </label>

            <label>
              <input type="checkbox" />
              ₹1,000 - ₹5,000
            </label>

            <label>
              <input type="checkbox" />
              ₹5,000 - ₹20,000
            </label>

            <label>
              <input type="checkbox" />
              Above ₹20,000
            </label>

          </div>

          <div className="filter-group">
            <h4>Customer Rating</h4>

            <label>
              <input type="checkbox" />
              ⭐ 4★ & above
            </label>

            <label>
              <input type="checkbox" />
              ⭐ 3★ & above
            </label>

          </div>

        </aside>

        {/* Products */}
        <main className="products-content">

          <div className="product-grid">

            {products.map((product) => {

              const discount = Math.round(
                ((product.oldPrice - product.price) /
                  product.oldPrice) *
                  100
              );

              return (
                <div className="product-card" key={product.id}>

                  <div className="product-image">
                    <span>{product.emoji}</span>

                    <span className="wishlist">
                      ♡
                    </span>
                  </div>

                  <div className="product-details">

                    <span className="product-category">
                      {product.category}
                    </span>

                    <h3>{product.name}</h3>

                    <div className="rating">
                      ⭐ {product.rating}
                    </div>

                    <div className="product-price">
                      <strong>
                        ₹{product.price.toLocaleString("en-IN")}
                      </strong>

                      <del>
                        ₹{product.oldPrice.toLocaleString("en-IN")}
                      </del>

                      <span>
                        {discount}% off
                      </span>
                    </div>

                    <Link
                      to={`/products/${product.id}`}
                      className="product-view-button"
                    >
                      View Product
                    </Link>

                  </div>

                </div>
              );
            })}

          </div>

        </main>

      </div>

    </div>
  );
}

export default Products;