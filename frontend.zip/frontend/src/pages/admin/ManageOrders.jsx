
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

function ManageOrders() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const fetchOrders = async () => {
    setLoading(true);
    setError("");

    try {
      const token = localStorage.getItem("shopzone_token");

      const response = await fetch(
        "http://localhost:5000/api/orders",
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Could not load orders.");
      }

      const orderList = Array.isArray(data)
        ? data
        : data.orders || [];

      setOrders(orderList);
    } catch (err) {
      setError(err.message || "Failed to load orders.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const updateOrderStatus = async (orderId, status) => {
    try {
      const token = localStorage.getItem("shopzone_token");

      const response = await fetch(
        `http://localhost:5000/api/orders/${orderId}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ status }),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Could not update order.");
      }

      await fetchOrders();
    } catch (err) {
      setError(err.message || "Failed to update order status.");
    }
  };

  if (loading) {
    return (
      <div className="admin-dashboard-page">
        <h2>Loading orders...</h2>
      </div>
    );
  }

  return (
    <div className="admin-dashboard-page">
      <div className="admin-welcome">
        <div>
          <p className="admin-eyebrow">SHOPZONE ADMIN PANEL</p>
          <h1>Manage Orders</h1>
          <p>Review customer orders and update their status.</p>
        </div>

        <Link to="/admin" className="admin-badge">
          ← Dashboard
        </Link>
      </div>

      {error && (
        <div className="auth-error" role="alert">
          {error}
          <button type="button" onClick={fetchOrders}>
            Retry
          </button>
        </div>
      )}

      <div className="admin-orders-list">
        {orders.length === 0 ? (
          <div className="admin-stat-card">
            <h3>No orders found</h3>
            <p>Customer orders will appear here when available.</p>
          </div>
        ) : (
          orders.map((order) => (
            <article className="admin-order-card" key={order._id}>
              <div>
                <h3>Order #{String(order._id).slice(-8)}</h3>
                <p>
                  Customer:{" "}
                  {order.user?.name ||
                    order.user?.email ||
                    "Customer"}
                </p>
                <p>
                  Total: ₹
                  {Number(
                    order.totalAmount ?? order.totalPrice ?? 0
                  ).toLocaleString("en-IN")}
                </p>
                <p>
                  Status: {order.status || "Pending"}
                </p>
              </div>

              <label className="admin-order-status">
                Update Status
                <select
                  value={order.status || "Pending"}
                  onChange={(event) =>
                    updateOrderStatus(
                      order._id,
                      event.target.value
                    )
                  }
                >
                  <option value="Pending">Pending</option>
                  <option value="Processing">Processing</option>
                  <option value="Shipped">Shipped</option>
                  <option value="Delivered">Delivered</option>
                  <option value="Cancelled">Cancelled</option>
                </select>
              </label>
            </article>
          ))
        )}
      </div>
    </div>
  );
}

export default ManageOrders;
