
import { Link } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";

function AdminDashboard() {
  const { user } = useAuth();

  const adminOptions = [
    {
      title: "Manage Products",
      description: "View, edit and delete existing products.",
      link: "/admin/products",
      icon: "📦",
    },
    {
      title: "Add Product",
      description: "Add a new product to the ShopZone store.",
      link: "/admin/products/add",
      icon: "➕",
    },
    {
      title: "Manage Orders",
      description: "View and manage customer orders.",
      link: "/admin/orders",
      icon: "🛍️",
    },
  ];

  return (
    <div className="admin-dashboard-page">
      <section className="admin-welcome">
        <div>
          <p className="admin-eyebrow">SHOPZONE ADMIN PANEL</p>
          <h1>Welcome, {user?.name || "Admin"}!</h1>
          <p>
            Manage your store products and customer orders from here.
          </p>
        </div>

        <span className="admin-badge">🛡️ Administrator</span>
      </section>

      <section className="admin-stats">
        <div className="admin-stat-card">
          <span>📦</span>
          <h3>Product Management</h3>
          <p>Organize your store catalogue.</p>
        </div>

        <div className="admin-stat-card">
          <span>🛒</span>
          <h3>Order Management</h3>
          <p>Review and process customer orders.</p>
        </div>

        <div className="admin-stat-card">
          <span>⚙️</span>
          <h3>Store Control</h3>
          <p>Manage your ShopZone store.</p>
        </div>
      </section>

      <section className="admin-management">
        <h2>Store Management</h2>
        <p className="admin-section-subtitle">
          Choose an option to continue.
        </p>

        <div className="admin-option-grid">
          {adminOptions.map((option) => (
            <Link
              to={option.link}
              className="admin-option-card"
              key={option.title}
            >
              <span className="admin-option-icon">{option.icon}</span>
              <h3>{option.title}</h3>
              <p>{option.description}</p>
              <span className="admin-option-link">
                Open Section →
              </span>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}

export default AdminDashboard;
