
import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";

function EditProduct() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: "",
    description: "",
    price: "",
    category: "",
    image: "",
    stock: "",
  });

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;

    async function fetchProduct() {
      try {
        const response = await fetch(
          `http://localhost:5000/api/products/${id}`
        );

        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.message || "Could not load product.");
        }

        const product = data.product || data;

        if (!cancelled) {
          setForm({
            name: product.name || "",
            description: product.description || "",
            price: product.price ?? "",
            category: product.category || "",
            image: product.image || "",
            stock: product.stock ?? "",
          });
        }
      } catch (err) {
        if (!cancelled) {
          setError(err.message || "Could not load product.");
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    fetchProduct();

    return () => {
      cancelled = true;
    };
  }, [id]);

  const handleChange = (event) => {
    setForm((previous) => ({
      ...previous,
      [event.target.name]: event.target.value,
    }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");
    setSaving(true);

    try {
      const token = localStorage.getItem("shopzone_token");

      const response = await fetch(
        `http://localhost:5000/api/products/${id}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            name: form.name.trim(),
            description: form.description.trim(),
            price: Number(form.price),
            category: form.category.trim(),
            image: form.image.trim(),
            stock: Number(form.stock),
          }),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Could not update product.");
      }

      alert("Product updated successfully!");
      navigate("/admin/products");
    } catch (err) {
      setError(
        err.message || "Could not connect to the server."
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="auth-page">Loading product...</div>;
  }

  return (
    <div className="auth-page">
      <div className="auth-card">
        <h1>Edit Product</h1>
        <p className="auth-subtitle">
          Update the product details below.
        </p>

        {error && (
          <div className="auth-error" role="alert">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <label htmlFor="edit-name">Product Name</label>
          <input
            id="edit-name"
            name="name"
            value={form.name}
            onChange={handleChange}
            required
          />

          <label htmlFor="edit-description">Description</label>
          <textarea
            id="edit-description"
            name="description"
            value={form.description}
            onChange={handleChange}
            required
          />

          <label htmlFor="edit-price">Price (₹)</label>
          <input
            id="edit-price"
            name="price"
            type="number"
            min="0.01"
            step="0.01"
            value={form.price}
            onChange={handleChange}
            required
          />

          <label htmlFor="edit-category">Category</label>
          <input
            id="edit-category"
            name="category"
            value={form.category}
            onChange={handleChange}
            required
          />

          <label htmlFor="edit-image">Image URL</label>
          <input
            id="edit-image"
            name="image"
            type="url"
            value={form.image}
            onChange={handleChange}
          />

          <label htmlFor="edit-stock">Stock Quantity</label>
          <input
            id="edit-stock"
            name="stock"
            type="number"
            min="0"
            step="1"
            value={form.stock}
            onChange={handleChange}
            required
          />

          <button
            type="submit"
            className="auth-submit"
            disabled={saving}
          >
            {saving ? "Saving Changes..." : "Update Product"}
          </button>
        </form>

        <p className="auth-switch">
          <Link to="/admin/products">
            ← Back to Manage Products
          </Link>
        </p>
      </div>
    </div>
  );
}

export default EditProduct;
