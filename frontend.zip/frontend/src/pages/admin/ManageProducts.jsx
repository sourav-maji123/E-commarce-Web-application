
import { useCallback, useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { adminRequest } from "../../services/adminApi";
import "./ManageProducts.css";

export default function ManageProducts() {
  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [busyId, setBusyId] = useState("");
  const [view, setView] = useState("grid");

  const loadProducts = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      const data = await adminRequest("/products?admin=true");
      const list = Array.isArray(data) ? data : data.products || [];
      setProducts(list);
    } catch (err) {
      setError(err.message || "Could not load products.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadProducts();
  }, [loadProducts]);

  const categories = useMemo(() => {
    return [
      "All",
      ...new Set(
        products
          .map((product) => product.category?.trim())
          .filter(Boolean)
      ),
    ];
  }, [products]);

  const filteredProducts = useMemo(() => {
    const query = search.trim().toLowerCase();

    return products.filter((product) => {
      const matchesSearch = [
        product.name,
        product.description,
        product.category,
      ]
        .filter(Boolean)
        .some((value) => value.toLowerCase().includes(query));

      const matchesCategory =
        category === "All" || product.category === category;

      return matchesSearch && matchesCategory;
    });
  }, [products, search, category]);

  const totalValue = products.reduce(
    (sum, product) =>
      sum + Number(product.price || 0) * Number(product.stock || 0),
    0
  );

  const lowStockCount = products.filter(
    (product) => Number(product.stock || 0) <= 5
  ).length;

  const handleDelete = async (product) => {
    const confirmed = window.confirm(
      `Are you sure you want to delete "${product.name}"? This action cannot be undone.`
    );

    if (!confirmed) return;

    setBusyId(product._id);
    setError("");
    setNotice("");

    try {
      await adminRequest(`/products/${product._id}`, {
        method: "DELETE",
      });

      setProducts((current) =>
        current.filter((item) => item._id !== product._id)
      );

      setNotice(`${product.name} was deleted successfully.`);
    } catch (err) {
      setError(err.message || "Could not delete this product.");
    } finally {
      setBusyId("");
    }
  };

  const formatPrice = (price) =>
    `₹${Number(price || 0).toLocaleString("en-IN", {
      maximumFractionDigits: 2,
    })}`;

  const ProductImage = ({ product }) =>
    product.image ? (
      <img
        className="mp-product-image"
        src={product.image}
        alt={product.name || "Product"}
        loading="lazy"
        onError={(event) => {
          event.currentTarget.style.display = "none";
          event.currentTarget.nextElementSibling.style.display = "grid";
        }}
      />
    ) : null;

  const ImagePlaceholder = () => (
    <div className="mp-image-placeholder">📦</div>
  );

  return (
    <main className="mp-page">
      <div className="mp-page-top">
        <div>
          <div className="mp-eyebrow">
            <span className="mp-eyebrow-dot" />
            SHOPZONE ADMINISTRATION
          </div>

          <h1>Product Management</h1>

          <p className="mp-subtitle">
            Manage your catalogue, inventory and product listings from one place.
          </p>
        </div>

        <Link to="/admin/products/add" className="mp-primary-button">
          <span>＋</span> Add Product
        </Link>
      </div>

      {error && (
        <div className="mp-alert mp-alert-error" role="alert">
          <span>⚠️</span>
          <p>{error}</p>
          <button onClick={() => setError("")} aria-label="Dismiss error">
            ×
          </button>
        </div>
      )}

      {notice && (
        <div className="mp-alert mp-alert-success" role="status">
          <span>✓</span>
          <p>{notice}</p>
          <button onClick={() => setNotice("")} aria-label="Dismiss message">
            ×
          </button>
        </div>
      )}

      <section className="mp-stats">
        <article className="mp-stat-card">
          <div className="mp-stat-icon mp-blue">▦</div>
          <div>
            <p>Total Products</p>
            <h2>{loading ? "—" : products.length}</h2>
            <span>Products in your catalogue</span>
          </div>
        </article>

        <article className="mp-stat-card">
          <div className="mp-stat-icon mp-green">₹</div>
          <div>
            <p>Inventory Value</p>
            <h2>{loading ? "—" : formatPrice(totalValue)}</h2>
            <span>Price × available stock</span>
          </div>
        </article>

        <article className="mp-stat-card">
          <div className="mp-stat-icon mp-orange">!</div>
          <div>
            <p>Low Stock</p>
            <h2>{loading ? "—" : lowStockCount}</h2>
            <span>Products with stock of 5 or less</span>
          </div>
        </article>
      </section>

      <section className="mp-catalogue">
        <div className="mp-section-heading">
          <div>
            <h2>Your Products</h2>
            <p>Search, review and manage your store inventory.</p>
          </div>

          <button
            className="mp-refresh-button"
            onClick={loadProducts}
            disabled={loading}
          >
            <span>↻</span> {loading ? "Loading..." : "Refresh"}
          </button>
        </div>

        <div className="mp-toolbar">
          <label className="mp-search">
            <span aria-hidden="true">⌕</span>
            <input
              type="search"
              placeholder="Search product name, description..."
              value={search}
              onChange={(event) => setSearch(event.target.value)}
            />
            {search && (
              <button
                type="button"
                onClick={() => setSearch("")}
                aria-label="Clear search"
              >
                ×
              </button>
            )}
          </label>

          <label className="mp-category-select">
            <span>Category</span>
            <select
              value={category}
              onChange={(event) => setCategory(event.target.value)}
            >
              {categories.map((item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              ))}
            </select>
          </label>

          <div className="mp-view-switch" aria-label="Product display mode">
            <button
              type="button"
              className={view === "grid" ? "active" : ""}
              onClick={() => setView("grid")}
              aria-label="Grid view"
              title="Grid view"
            >
              ▦
            </button>
            <button
              type="button"
              className={view === "list" ? "active" : ""}
              onClick={() => setView("list")}
              aria-label="List view"
              title="List view"
            >
              ☷
            </button>
          </div>
        </div>

        <div className="mp-results-line">
          <span>
            Showing <strong>{loading ? 0 : filteredProducts.length}</strong> of{" "}
            <strong>{loading ? "—" : products.length}</strong> products
          </span>

          {(search || category !== "All") && (
            <button
              type="button"
              className="mp-clear-filters"
              onClick={() => {
                setSearch("");
                setCategory("All");
              }}
            >
              Clear filters
            </button>
          )}
        </div>

        {loading ? (
          <div className="mp-loading">
            <div className="mp-spinner" />
            <p>Loading your products...</p>
          </div>
        ) : filteredProducts.length === 0 ? (
          <div className="mp-empty">
            <div className="mp-empty-icon">📦</div>
            <h3>{products.length ? "No matching products" : "Your catalogue is empty"}</h3>
            <p>
              {products.length
                ? "Try another search term or choose a different category."
                : "Add your first product to start building your ShopZone catalogue."}
            </p>

            {products.length === 0 ? (
              <Link to="/admin/products/add" className="mp-primary-button">
                ＋ Add Your First Product
              </Link>
            ) : (
              <button
                className="mp-secondary-button"
                onClick={() => {
                  setSearch("");
                  setCategory("All");
                }}
              >
                Clear Filters
              </button>
            )}
          </div>
        ) : (
          <div className={`mp-products ${view === "list" ? "mp-list-view" : ""}`}>
            {filteredProducts.map((product) => {
              const isLowStock = Number(product.stock || 0) <= 5;
              const isActive = product.isActive !== false;

              return (
                <article className="mp-product-card" key={product._id}>
                  <div className="mp-product-visual">
                    {product.image ? (
                      <>
                        <ProductImage product={product} />
                        <div
                          className="mp-image-placeholder"
                          style={{ display: "none" }}
                        >
                          📦
                        </div>
                      </>
                    ) : (
                      <ImagePlaceholder />
                    )}

                    <span
                      className={`mp-status ${isActive ? "mp-status-active" : "mp-status-hidden"}`}
                    >
                      <span />
                      {isActive ? "Active" : "Hidden"}
                    </span>
                  </div>

                  <div className="mp-product-content">
                    <div className="mp-product-category">
                      {product.category || "General"}
                    </div>

                    <h3 title={product.name}>{product.name}</h3>

                    <p className="mp-product-description">
                      {product.description || "No description provided."}
                    </p>

                    <div className="mp-product-price">
                      {formatPrice(product.price)}
                    </div>

                    <div className="mp-stock-row">
                      <span>Stock available</span>
                      <strong className={isLowStock ? "mp-low-stock" : ""}>
                        {product.stock ?? 0} units
                      </strong>
                    </div>

                    <div className="mp-stock-track">
                      <span
                        className={isLowStock ? "mp-stock-track-low" : ""}
                        style={{
                          width: `${Math.min(
                            100,
                            Math.max(4, (Number(product.stock || 0) / 50) * 100)
                          )}%`,
                        }}
                      />
                    </div>

                    {isLowStock && (
                      <div className="mp-low-stock-note">
                        ⚠️ {Number(product.stock || 0) === 0
                          ? "Out of stock"
                          : "Stock running low"}
                      </div>
                    )}

                    <div className="mp-product-actions">
                      <Link
                        to={`/admin/products/edit/${product._id}`}
                        className="mp-edit-button"
                      >
                        ✎ Edit Product
                      </Link>

                      <button
                        type="button"
                        className="mp-delete-button"
                        disabled={busyId === product._id}
                        onClick={() => handleDelete(product)}
                        aria-label={`Delete ${product.name}`}
                        title="Delete product"
                      >
                        {busyId === product._id ? "…" : "⌫"}
                      </button>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>

      <div className="mp-footer-note">
        <span>🔒</span>
        Product changes are saved through your ShopZone backend.
      </div>
    </main>
  );
}
