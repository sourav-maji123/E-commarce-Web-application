
import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";

function AddProduct() {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: "",
    description: "",
    price: "",
    category: "",
    image: "",
    stock: "",
  });

  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleChange = (event) => {
    setForm({
      ...form,
      [event.target.name]: event.target.value,
    });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");
    setLoading(true);

    try {
      const token = localStorage.getItem("shopzone_token");

      const response = await fetch(
        "http://localhost:5000/api/products",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            name: form.name.trim(),
            description: form.description.trim(),
            price: Number(form.price),
            category: form.category.trim(),
            image: form.image.trim(),
            stock: Number(form.stock),
          }),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Could not add product.");
      }

      alert("Product added successfully!");
      navigate("/admin/products");
    } catch (err) {
      setError(
        err.message ||
          "Could not connect to the server. Please try again."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        <h1>Add New Product</h1>
        <p className="auth-subtitle">
          Enter the product details below.
        </p>

        {error && (
          <div className="auth-error" role="alert">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <label htmlFor="product-name">Product Name</label>
          <input
            id="product-name"
            name="name"
            value={form.name}
            onChange={handleChange}
            required
          />

          <label htmlFor="product-description">Description</label>
          <textarea
            id="product-description"
            name="description"
            value={form.description}
            onChange={handleChange}
            required
          />

          <label htmlFor="product-price">Price (₹)</label>
          <input
            id="product-price"
            name="price"
            type="number"
            min="0.01"
            step="0.01"
            value={form.price}
            onChange={handleChange}
            required
          />

          <label htmlFor="product-category">Category</label>
          <input
            id="product-category"
            name="category"
            value={form.category}
            onChange={handleChange}
            required
          />

          <label htmlFor="product-image">Image URL</label>
          <input
            id="product-image"
            name="image"
            type="url"
            placeholder="https://example.com/product.jpg"
            value={form.image}
            onChange={handleChange}
          />

          <label htmlFor="product-stock">Stock Quantity</label>
          <input
            id="product-stock"
            name="stock"
            type="number"
            min="0"
            step="1"
            value={form.stock}
            onChange={handleChange}
            required
          />

          <button
            type="submit"
            className="auth-submit"
            disabled={loading}
          >
            {loading ? "Adding Product..." : "Add Product"}
          </button>
        </form>

        <p className="auth-switch">
          <Link to="/admin/products">
            ← Back to Manage Products
          </Link>
        </p>
      </div>
    </div>
  );
}

export default AddProduct;
