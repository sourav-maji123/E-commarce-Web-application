import { Link } from "react-router-dom";

const products = [
  {
    id: 1,
    name: "Wireless Headphones",
    price: "1,499",
    oldPrice: "2,999",
    discount: "50% off",
    emoji: "🎧",
  },
  {
    id: 2,
    name: "Smart Watch",
    price: "2,499",
    oldPrice: "4,999",
    discount: "50% off",
    emoji: "⌚",
  },
  {
    id: 3,
    name: "Running Shoes",
    price: "1,999",
    oldPrice: "3,999",
    discount: "50% off",
    emoji: "👟",
  },
  {
    id: 4,
    name: "Laptop Backpack",
    price: "899",
    oldPrice: "1,799",
    discount: "50% off",
    emoji: "🎒",
  },
  {
    id: 5,
    name: "Smartphone",
    price: "15,999",
    oldPrice: "19,999",
    discount: "20% off",
    emoji: "📱",
  },
];

function Home() {
  return (
    <div className="home-page">

      {/* Hero Banner */}
      <section className="hero-banner">

        <div className="hero-text">

          <p className="hero-small">
            BIG SAVINGS DAYS
          </p>

          <h1>
            Upgrade Your
            <br />
            Everyday Life
          </h1>

          <p className="hero-description">
            Discover amazing deals on electronics,
            fashion, lifestyle and more.
          </p>

          <Link to="/products" className="hero-button">
            Shop Now →
          </Link>

        </div>

        <div className="hero-visual">
          <div className="hero-circle">
            🛍️
          </div>

          <div className="floating-product product-one">
            📱
          </div>

          <div className="floating-product product-two">
            🎧
          </div>

          <div className="floating-product product-three">
            ⌚
          </div>
        </div>

      </section>

      {/* Deals Section */}
      <section className="section-container">

        <div className="section-heading">
          <div>
            <h2>Deals of the Day</h2>
            <p>Grab the best deals before they're gone</p>
          </div>

          <Link to="/products" className="view-all">
            View All →
          </Link>
        </div>

        <div className="product-row">

          {products.map((product) => (
            <div className="home-product-card" key={product.id}>

              <div className="home-product-image">
                {product.emoji}
              </div>

              <div className="home-product-info">

                <h3>{product.name}</h3>

                <div className="price-row">
                  <strong>₹{product.price}</strong>
                  <del>₹{product.oldPrice}</del>
                </div>

                <p className="discount">
                  {product.discount}
                </p>

              </div>

            </div>
          ))}

        </div>

      </section>

      {/* Categories */}
      <section className="section-container">

        <div className="section-heading">
          <div>
            <h2>Shop By Category</h2>
            <p>Find everything you need</p>
          </div>
        </div>

        <div className="category-cards">

          <Link to="/products" className="category-card">
            <div>📱</div>
            <h3>Mobiles</h3>
            <p>Latest Smartphones</p>
          </Link>

          <Link to="/products" className="category-card">
            <div>💻</div>
            <h3>Electronics</h3>
            <p>Best Technology</p>
          </Link>

          <Link to="/products" className="category-card">
            <div>👕</div>
            <h3>Fashion</h3>
            <p>Trending Styles</p>
          </Link>

          <Link to="/products" className="category-card">
            <div>🏠</div>
            <h3>Home</h3>
            <p>Make Your Home Better</p>
          </Link>

          <Link to="/products" className="category-card">
            <div>🎧</div>
            <h3>Accessories</h3>
            <p>Smart Accessories</p>
          </Link>

        </div>

      </section>

      {/* Benefits */}
      <section className="benefits-section">

        <div className="benefit">
          <span>🚚</span>
          <div>
            <h3>Fast Delivery</h3>
            <p>Quick delivery at your doorstep</p>
          </div>
        </div>

        <div className="benefit">
          <span>🔒</span>
          <div>
            <h3>Secure Payment</h3>
            <p>100% secure payment options</p>
          </div>
        </div>

        <div className="benefit">
          <span>↩️</span>
          <div>
            <h3>Easy Returns</h3>
            <p>Simple and hassle-free returns</p>
          </div>
        </div>

        <div className="benefit">
          <span>⭐</span>
          <div>
            <h3>Quality Products</h3>
            <p>Products you can trust</p>
          </div>
        </div>

      </section>

    </div>
  );
}

export default Home;