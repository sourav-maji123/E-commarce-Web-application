
import { useState } from "react";
import { useAuth } from "../../context/AuthContext";
import { useNavigate } from "react-router-dom";

function Profile() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [message, setMessage] = useState("");

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  if (!user) {
    return (
      <section className="profile-page">
        <h2>My Profile</h2>
        <p>Please log in to view your profile.</p>
        <button onClick={() => navigate("/login")}>
          Login
        </button>
      </section>
    );
  }

  const initial = user.name?.charAt(0)?.toUpperCase() || "U";

  return (
    <section className="profile-page">
      <div className="profile-card">
        <div className="profile-avatar">{initial}</div>

        <h2>My Profile</h2>
        <p>Manage your ShopZone account.</p>

        <div className="profile-details">
          <div className="profile-detail">
            <strong>Full Name</strong>
            <span>{user.name || "Not available"}</span>
          </div>

          <div className="profile-detail">
            <strong>Email Address</strong>
            <span>{user.email || "Not available"}</span>
          </div>

          <div className="profile-detail">
            <strong>Account Type</strong>
            <span>
              {user.role === "admin" ? "Administrator" : "Customer"}
            </span>
          </div>
        </div>

        {message && <p>{message}</p>}

        <div className="profile-actions">
          <button
            type="button"
            onClick={() => navigate("/my-orders")}
          >
            My Orders
          </button>

          <button
            type="button"
            onClick={() => {
              setMessage("You are logged out successfully.");
              handleLogout();
            }}
          >
            Logout
          </button>
        </div>
      </div>
    </section>
  );
}

export default Profile;
