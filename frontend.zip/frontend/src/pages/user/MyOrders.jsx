
import { useEffect, useState } from "react";

const API_URL = "http://localhost:5000/api/orders";

function MyOrders() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const token = localStorage.getItem("shopzone_token");

        const response = await fetch(API_URL, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.message || "Failed to load orders.");
        }

        setOrders(Array.isArray(data) ? data : data.orders || []);
      } catch (err) {
        setError(err.message || "Unable to load orders.");
      } finally {
        setLoading(false);
      }
    };

    fetchOrders();
  }, []);

  if (loading) {
    return (
      <div className="orders-page">
        <h2>My Orders</h2>
        <p>Loading your orders...</p>
      </div>
    );
  }

  return (
    <div className="orders-page">
      <h2>My Orders</h2>
      <p>Track your ShopZone purchases here.</p>

      {error && <p className="auth-error">{error}</p>}

      {!error && orders.length === 0 && (
        <div className="orders-empty">
          <h3>No orders yet!</h3>
          <p>Your orders will appear here after checkout.</p>
          <a href="/products">Explore Products</a>
        </div>
      )}

      {orders.map((order) => (
        <div className="order-card" key={order._id}>
          <h3>Order #{String(order._id).slice(-8)}</h3>

          <p>
            <strong>Date:</strong>{" "}
            {order.createdAt
              ? new Date(order.createdAt).toLocaleDateString()
              : "N/A"}
          </p>

          <p>
            <strong>Status:</strong> {order.status || "Pending"}
          </p>

          <p>
            <strong>Total:</strong> ₹
            {Number(
              order.totalAmount ?? order.total ?? 0
            ).toLocaleString("en-IN")}
          </p>

          {Array.isArray(order.items) && (
            <div>
              <strong>Products:</strong>
              {order.items.map((item, index) => (
                <p key={item._id || index}>
                  {item.name || item.product?.name || "Product"} ×{" "}
                  {item.quantity || 1}
                </p>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

export default MyOrders;
